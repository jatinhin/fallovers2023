

export const COUNTRY_LIST_API = process.env.PUBLIC_URL + '/media/json/CountryCodes.json';
