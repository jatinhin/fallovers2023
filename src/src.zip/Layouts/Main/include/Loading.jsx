import React from 'react';

  function Loading(props) {

return (

    <div className="col-sm-12 col-md-12 d-flex align-items-center justify-content-center">
        <div>Please wait...</div>    
    </div>

  )
}

export default Loading
