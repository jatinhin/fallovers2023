// export const baseUrl = 'https://khushonlineshopee.com/fallovers/api/v1'
export const baseUrl = 'http://localhost/sites/fallovers/api/v1'
export const BASE_URL = 'http://localhost:3000/fallovers-new'
export const IMAGES_URL = 'http://localhost:3000/fallovers-new'

//export const BASE_URL = 'https://khushonlineshopee.com/fallovers-new/'

export const loginUrl     = `${baseUrl}/login`
export const homepageData = `${baseUrl}/get-homepage`

